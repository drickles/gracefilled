$(document).ready(function(){

    function startOverlay(overlayID){
        $('.overlay-veil').fadeTo('500', '0.8', function(){
            var element = $('div[data-overlayItem="' + overlayID + '"]');

            element.fadeIn('300');
            element.addClass('active');
        })
    }



    function closeOverlayAll(overlayID){

        $('.overlay-component').each(function(){
            if ($(this).hasClass('active')) {
                $('.overlay-veil').fadeOut();
                $(this).fadeOut('300', function(){
                    $(this).removeClass('active');
                })
            }
        });

        if (overlayID !== false){
            startOverlay(overlayID);
        }
    }

    $('.closeOverlay').on('click', function(){
        closeOverlayAll(false);
    })


    $('.overlay-item-click').on('click', function(e){
        e.preventDefault();

        var overlayID = $(this).data('overlay');

        closeOverlayAll(overlayID);
    })

})  // END

















