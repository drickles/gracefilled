<?php
$servername = "localhost";
$username = "gracefil_drickle";
$password = "Mobile33#";
$dbname ="gracefil_products";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
?>